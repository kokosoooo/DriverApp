package com.spartons.driverapp.model

data class Driver(val lat: Double, val lng: Double, val driverId: String = "0000")